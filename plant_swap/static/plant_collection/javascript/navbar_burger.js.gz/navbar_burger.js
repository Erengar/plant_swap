$('.navbar-burger').on('click', function() {
    $('.navbar-burger').toggleClass('is-active');
    $('#navMenu').toggleClass('is-active');
})